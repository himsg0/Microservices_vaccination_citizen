package com.security.SecurityService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
